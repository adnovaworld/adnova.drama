import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  bigint,
  boolean,
  decimal,
  json,
  uniqueIndex,
} from "drizzle-orm/mysql-core";

// ── Users (OAuth) ──────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ── Local Auth (password-based) ────────────────────────────────
export const localUsers = mysqlTable("local_users", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type LocalUser = typeof localUsers.$inferSelect;

// ── Categories ─────────────────────────────────────────────────
export const categories = mysqlTable("categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  description: text("description"),
  image: varchar("image", { length: 500 }),
  color: varchar("color", { length: 7 }),
  sortOrder: int("sortOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Category = typeof categories.$inferSelect;

// ── Stories ────────────────────────────────────────────────────
export const stories = mysqlTable("stories", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  description: text("description"),
  coverImage: varchar("coverImage", { length: 500 }),
  categoryId: bigint("categoryId", { mode: "number", unsigned: true }).references(
    () => categories.id
  ),
  type: mysqlEnum("type", ["audio", "comic", "text", "video"]).notNull(),
  status: mysqlEnum("status", ["ongoing", "completed", "coming_soon"]).default("ongoing"),
  author: varchar("author", { length: 255 }),
  rating: decimal("rating", { precision: 2, scale: 1 }).default("0.0"),
  totalViews: bigint("totalViews", { mode: "number" }).default(0),
  totalEpisodes: int("totalEpisodes").default(0),
  isPremium: boolean("isPremium").default(false),
  isExclusive: boolean("isExclusive").default(false),
  isFeatured: boolean("isFeatured").default(false),
  tags: json("tags").$type<string[]>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Story = typeof stories.$inferSelect;

// ── Episodes ───────────────────────────────────────────────────
export const episodes = mysqlTable("episodes", {
  id: serial("id").primaryKey(),
  storyId: bigint("storyId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => stories.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 255 }).notNull(),
  episodeNumber: int("episodeNumber").notNull(),
  description: text("description"),
  coverImage: varchar("coverImage", { length: 500 }),
  audioUrl: varchar("audioUrl", { length: 500 }),
  audioDuration: int("audioDuration"),
  content: text("content"),
  readingTime: int("readingTime"),
  comicPages: json("comicPages").$type<string[]>(),
  videoUrl: varchar("videoUrl", { length: 500 }),
  videoDuration: int("videoDuration"),
  isPremium: boolean("isPremium").default(false),
  publishedAt: timestamp("publishedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Episode = typeof episodes.$inferSelect;

// ── User Favorites ─────────────────────────────────────────────
export const userFavorites = mysqlTable(
  "user_favorites",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    storyId: bigint("storyId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => stories.id, { onDelete: "cascade" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("user_story_fav_idx").on(table.userId, table.storyId),
  ]
);

export type UserFavorite = typeof userFavorites.$inferSelect;

// ── User Bookmarks ─────────────────────────────────────────────
export const userBookmarks = mysqlTable(
  "user_bookmarks",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    storyId: bigint("storyId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => stories.id, { onDelete: "cascade" }),
    episodeId: bigint("episodeId", { mode: "number", unsigned: true })
      .references(() => episodes.id, { onDelete: "cascade" }),
    pageNumber: int("pageNumber").default(1),
    progress: int("progress").default(0),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt")
      .defaultNow()
      .notNull()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("user_story_bookmark_idx").on(table.userId, table.storyId),
  ]
);

export type UserBookmark = typeof userBookmarks.$inferSelect;

// ── Continue Watching/Reading ──────────────────────────────────
export const userContinue = mysqlTable(
  "user_continue",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    storyId: bigint("storyId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => stories.id, { onDelete: "cascade" }),
    episodeId: bigint("episodeId", { mode: "number", unsigned: true })
      .references(() => episodes.id, { onDelete: "cascade" }),
    progress: int("progress").default(0),
    updatedAt: timestamp("updatedAt")
      .defaultNow()
      .notNull()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("user_story_continue_idx").on(table.userId, table.storyId),
  ]
);

export type UserContinue = typeof userContinue.$inferSelect;

// ── Reviews ────────────────────────────────────────────────────
export const reviews = mysqlTable(
  "reviews",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    storyId: bigint("storyId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => stories.id, { onDelete: "cascade" }),
    rating: int("rating").notNull(),
    comment: text("comment"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("user_story_review_idx").on(table.userId, table.storyId),
  ]
);

export type Review = typeof reviews.$inferSelect;

// ── Subscriptions ──────────────────────────────────────────────
export const subscriptions = mysqlTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  plan: mysqlEnum("plan", ["free", "premium", "vip"]).notNull(),
  status: mysqlEnum("status", ["active", "cancelled", "expired"]).default("active"),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt"),
  paymentMethod: varchar("paymentMethod", { length: 50 }),
  transactionId: varchar("transactionId", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Subscription = typeof subscriptions.$inferSelect;

// ── Notifications ──────────────────────────────────────────────
export const notifications = mysqlTable("notifications", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message"),
  type: mysqlEnum("type", ["episode", "system", "promo"]).default("episode"),
  isRead: boolean("isRead").default(false),
  storyId: bigint("storyId", { mode: "number", unsigned: true })
    .references(() => stories.id, { onDelete: "set null" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
