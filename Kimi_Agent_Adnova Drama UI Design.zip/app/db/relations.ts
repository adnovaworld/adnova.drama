import { relations } from "drizzle-orm";
import {
  users,
  localUsers,
  categories,
  stories,
  episodes,
  userFavorites,
  userBookmarks,
  userContinue,
  reviews,
  subscriptions,
  notifications,
} from "./schema";

export const usersRelations = relations(users, ({ many, one }) => ({
  localUser: one(localUsers),
  favorites: many(userFavorites),
  bookmarks: many(userBookmarks),
  continueWatching: many(userContinue),
  reviews: many(reviews),
  subscriptions: many(subscriptions),
  notifications: many(notifications),
}));

export const categoriesRelations = relations(categories, ({ many }) => ({
  stories: many(stories),
}));

export const storiesRelations = relations(stories, ({ one, many }) => ({
  category: one(categories, {
    fields: [stories.categoryId],
    references: [categories.id],
  }),
  episodes: many(episodes),
  favorites: many(userFavorites),
  bookmarks: many(userBookmarks),
  continueWatching: many(userContinue),
  reviews: many(reviews),
  notifications: many(notifications),
}));

export const episodesRelations = relations(episodes, ({ one }) => ({
  story: one(stories, {
    fields: [episodes.storyId],
    references: [stories.id],
  }),
}));

export const userFavoritesRelations = relations(userFavorites, ({ one }) => ({
  user: one(users, {
    fields: [userFavorites.userId],
    references: [users.id],
  }),
  story: one(stories, {
    fields: [userFavorites.storyId],
    references: [stories.id],
  }),
}));

export const userBookmarksRelations = relations(userBookmarks, ({ one }) => ({
  user: one(users, {
    fields: [userBookmarks.userId],
    references: [users.id],
  }),
  story: one(stories, {
    fields: [userBookmarks.storyId],
    references: [stories.id],
  }),
  episode: one(episodes, {
    fields: [userBookmarks.episodeId],
    references: [episodes.id],
  }),
}));

export const userContinueRelations = relations(userContinue, ({ one }) => ({
  user: one(users, {
    fields: [userContinue.userId],
    references: [users.id],
  }),
  story: one(stories, {
    fields: [userContinue.storyId],
    references: [stories.id],
  }),
  episode: one(episodes, {
    fields: [userContinue.episodeId],
    references: [episodes.id],
  }),
}));

export const reviewsRelations = relations(reviews, ({ one }) => ({
  user: one(users, {
    fields: [reviews.userId],
    references: [users.id],
  }),
  story: one(stories, {
    fields: [reviews.storyId],
    references: [stories.id],
  }),
}));

export const subscriptionsRelations = relations(subscriptions, ({ one }) => ({
  user: one(users, {
    fields: [subscriptions.userId],
    references: [users.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
  story: one(stories, {
    fields: [notifications.storyId],
    references: [stories.id],
  }),
}));
