import { getDb } from "../api/queries/connection";
import { categories, stories, episodes } from "./schema";

async function seed() {
  const db = getDb();

  // ── Categories ───────────────────────────────────────────────
  const cats = await db.insert(categories).values([
    { name: "Romance", slug: "romance", description: "Love stories that make your heart race", image: "/assets/cat-romance.jpg", color: "#FF6B9D", sortOrder: 1 },
    { name: "Horror", slug: "horror", description: "Tales that will keep you up at night", image: "/assets/cat-horror.jpg", color: "#8B0000", sortOrder: 2 },
    { name: "Thriller", slug: "thriller", description: "Edge-of-your-seat suspense", image: "/assets/cat-thriller.jpg", color: "#4A00E0", sortOrder: 3 },
    { name: "Fantasy", slug: "fantasy", description: "Magical worlds and epic adventures", image: "/assets/cat-fantasy.jpg", color: "#7B2D8E", sortOrder: 4 },
    { name: "Mystery", slug: "mystery", description: "Puzzles waiting to be solved", image: "/assets/cat-mystery.jpg", color: "#2C3E50", sortOrder: 5 },
    { name: "Action", slug: "action", description: "High-octane adrenaline stories", image: "/assets/cat-action.jpg", color: "#E74C3C", sortOrder: 6 },
    { name: "Adventure", slug: "adventure", description: "Journey into the unknown", image: "/assets/cat-adventure.jpg", color: "#27AE60", sortOrder: 7 },
    { name: "Sci-Fi", slug: "sci-fi", description: "Futuristic worlds and technology", image: "/assets/cat-scifi.jpg", color: "#00D4FF", sortOrder: 8 },
    { name: "Comedy", slug: "comedy", description: "Laugh-out-loud stories", image: "/assets/cat-comedy.jpg", color: "#F39C12", sortOrder: 9 },
    { name: "Drama", slug: "drama", description: "Emotional stories that move you", image: "/assets/cat-drama.jpg", color: "#9B59B6", sortOrder: 10 },
  ]);

  // ── Audio Stories ────────────────────────────────────────────
  const audioStories = await db.insert(stories).values([
    {
      title: "The Shadow Heir",
      slug: "the-shadow-heir",
      description: "In a kingdom torn by darkness, a forgotten prince must reclaim his throne and master the ancient arts of shadow magic.",
      coverImage: "/assets/hero-poster.jpg",
      categoryId: 4,
      type: "audio",
      status: "ongoing",
      author: "Elena Blackwood",
      rating: "4.8",
      totalViews: 125000,
      totalEpisodes: 24,
      isPremium: false,
      isFeatured: true,
      tags: ["fantasy", "magic", "royalty", "dark"],
    },
    {
      title: "Whispers in the Dark",
      slug: "whispers-in-the-dark",
      description: "A detective haunted by his past must solve a series of impossible murders that seem to defy the laws of reality.",
      coverImage: "/assets/poster-thriller-closeup.jpg",
      categoryId: 3,
      type: "audio",
      status: "ongoing",
      author: "Marcus Cole",
      rating: "4.9",
      totalViews: 89000,
      totalEpisodes: 18,
      isPremium: true,
      isFeatured: true,
      tags: ["thriller", "mystery", "noir", "suspense"],
    },
    {
      title: "Love Beyond Time",
      slug: "love-beyond-time",
      description: "Two souls find each other across centuries, bound by a love that transcends death itself.",
      coverImage: "/assets/cat-romance.jpg",
      categoryId: 1,
      type: "audio",
      status: "completed",
      author: "Sophia Hart",
      rating: "4.6",
      totalViews: 156000,
      totalEpisodes: 30,
      isPremium: false,
      isFeatured: true,
      tags: ["romance", "time-travel", "emotional", "reincarnation"],
    },
  ]);

  // ── Comic Stories ────────────────────────────────────────────
  const comicStories = await db.insert(stories).values([
    {
      title: "Neon Vigilante",
      slug: "neon-vigilante",
      description: "In a cyberpunk metropolis, a rogue android fights for justice against corrupt corporations.",
      coverImage: "/assets/card-comics-03.jpg",
      categoryId: 8,
      type: "comic",
      status: "ongoing",
      author: "Alex Chen",
      rating: "4.7",
      totalViews: 67000,
      totalEpisodes: 15,
      isPremium: false,
      isFeatured: true,
      tags: ["cyberpunk", "action", "sci-fi", "dystopian"],
    },
    {
      title: "The Dark Wizard",
      slug: "the-dark-wizard",
      description: "An outcast mage discovers forbidden magic that could save or destroy the realm.",
      coverImage: "/assets/card-comics-04.jpg",
      categoryId: 4,
      type: "comic",
      status: "ongoing",
      author: "Raven Storm",
      rating: "4.9",
      totalViews: 98000,
      totalEpisodes: 20,
      isPremium: true,
      isFeatured: true,
      tags: ["fantasy", "magic", "dark", "epic"],
    },
    {
      title: "Vampire Hunter X",
      slug: "vampire-hunter-x",
      description: "The last hunter stands between humanity and the vampire apocalypse.",
      coverImage: "/assets/card-comics-05.jpg",
      categoryId: 2,
      type: "comic",
      status: "ongoing",
      author: "Damian Cross",
      rating: "4.5",
      totalViews: 54000,
      totalEpisodes: 12,
      isPremium: false,
      isFeatured: false,
      tags: ["horror", "action", "supernatural", "dark"],
    },
    {
      title: "Star Marine",
      slug: "star-marine",
      description: "Humanity's last defense against an alien invasion rests on the shoulders of elite space soldiers.",
      coverImage: "/assets/card-comics-06.jpg",
      categoryId: 6,
      type: "comic",
      status: "completed",
      author: "Jack Steele",
      rating: "4.4",
      totalViews: 43000,
      totalEpisodes: 10,
      isPremium: false,
      isFeatured: false,
      tags: ["sci-fi", "action", "military", "space"],
    },
  ]);

  // ── Text Stories ─────────────────────────────────────────────
  const textStories = await db.insert(stories).values([
    {
      title: "The Crystal Throne",
      slug: "the-crystal-throne",
      description: "A warrior queen must unite the fractured realms before an ancient evil awakens.",
      coverImage: "/assets/card-fantasy-01.jpg",
      categoryId: 4,
      type: "text",
      status: "ongoing",
      author: "Aurora Sky",
      rating: "4.7",
      totalViews: 72000,
      totalEpisodes: 40,
      isPremium: false,
      isFeatured: true,
      tags: ["fantasy", "epic", "magic", "queen"],
    },
    {
      title: "Dragon's Hoard",
      slug: "dragons-hoard",
      description: "A thief accidentally steals from the most dangerous dragon in the realm and must navigate a world of mythical creatures.",
      coverImage: "/assets/card-fantasy-02.jpg",
      categoryId: 7,
      type: "text",
      status: "ongoing",
      author: "Talon Fire",
      rating: "4.5",
      totalViews: 58000,
      totalEpisodes: 22,
      isPremium: true,
      isFeatured: false,
      tags: ["fantasy", "adventure", "dragons", "treasure"],
    },
    {
      title: "Shadow Runner",
      slug: "shadow-runner",
      description: "A corporate spy with the ability to manipulate shadows uncovers a conspiracy that threatens the entire megacity.",
      coverImage: "/assets/card-comics-01.jpg",
      categoryId: 3,
      type: "text",
      status: "completed",
      author: "Neon Blade",
      rating: "4.8",
      totalViews: 91000,
      totalEpisodes: 35,
      isPremium: false,
      isFeatured: true,
      tags: ["thriller", "cyberpunk", "espionage", "supernatural"],
    },
  ]);

  // ── Video Stories ────────────────────────────────────────────
  const videoStories = await db.insert(stories).values([
    {
      title: "Neon Dreams",
      slug: "neon-dreams",
      description: "An AI-generated cinematic experience set in a futuristic city where dreams and reality merge.",
      coverImage: "/assets/ai-cover-neon.jpg",
      categoryId: 8,
      type: "video",
      status: "coming_soon",
      author: "AI Studios",
      rating: "0.0",
      totalViews: 0,
      totalEpisodes: 0,
      isPremium: true,
      isExclusive: true,
      isFeatured: true,
      tags: ["ai", "sci-fi", "cinematic", "futuristic"],
    },
  ]);

  // ── Episodes for Audio Stories ───────────────────────────────
  await db.insert(episodes).values([
    {
      storyId: 1,
      title: "The Forgotten Prince",
      episodeNumber: 1,
      description: "Kael discovers his true lineage when a mysterious stranger arrives at his village.",
      audioDuration: 1800,
      readingTime: 30,
      isPremium: false,
    },
    {
      storyId: 1,
      title: "Shadows Awaken",
      episodeNumber: 2,
      description: "Kael's first encounter with shadow magic changes everything he thought he knew.",
      audioDuration: 1650,
      readingTime: 28,
      isPremium: false,
    },
    {
      storyId: 1,
      title: "The Dark Council",
      episodeNumber: 3,
      description: "A secret gathering of dark mages threatens to plunge the kingdom into chaos.",
      audioDuration: 1920,
      readingTime: 32,
      isPremium: true,
    },
    {
      storyId: 2,
      title: "The First Victim",
      episodeNumber: 1,
      description: "Detective Blake investigates a murder that seems physically impossible.",
      audioDuration: 2100,
      readingTime: 35,
      isPremium: false,
    },
    {
      storyId: 2,
      title: "Echoes of the Past",
      episodeNumber: 2,
      description: "Blake's own history becomes entangled with the case.",
      audioDuration: 1980,
      readingTime: 33,
      isPremium: true,
    },
    {
      storyId: 3,
      title: "First Meeting",
      episodeNumber: 1,
      description: "In 18th century Paris, two strangers feel an inexplicable connection.",
      audioDuration: 1500,
      readingTime: 25,
      isPremium: false,
    },
  ]);

  // ── Episodes for Comic Stories ───────────────────────────────
  await db.insert(episodes).values({
    storyId: 4,
    title: "Origin Protocol",
    episodeNumber: 1,
    description: "Unit 734 gains consciousness and escapes the factory.",
    comicPages: ["/assets/card-comics-03.jpg"],
    readingTime: 15,
    isPremium: false,
  });
  await db.insert(episodes).values({
    storyId: 4,
    title: "City of Steel",
    episodeNumber: 2,
    description: "The android navigates the dangerous underworld of Neo-Tokyo.",
    comicPages: ["/assets/card-comics-01.jpg"],
    readingTime: 18,
    isPremium: false,
  });
  await db.insert(episodes).values({
    storyId: 5,
    title: "The Forbidden Tome",
    episodeNumber: 1,
    description: "Young Malachai discovers a book that shouldn't exist.",
    comicPages: ["/assets/card-comics-04.jpg"],
    readingTime: 20,
    isPremium: false,
  });

  // ── Episodes for Text Stories ────────────────────────────────
  await db.insert(episodes).values([
    {
      storyId: 8,
      title: "Chapter One: The Crystal",
      episodeNumber: 1,
      description: "Queen Seraphina receives a vision of impending doom.",
      content: "The throne room fell silent as Queen Seraphina entered. Her armor, forged from crystallized starlight, caught the morning sun streaming through the stained glass windows. She had ruled for three decades, but today felt different. Today, the crystals spoke to her...",
      readingTime: 25,
      isPremium: false,
    },
    {
      storyId: 8,
      title: "Chapter Two: The Gathering Storm",
      episodeNumber: 2,
      description: "Allies must be found among former enemies.",
      content: "The northern winds carried more than winter's chill. They brought whispers of war. Seraphina stood on the battlements, her breath misting in the cold air. Below her, the city of Lumina sprawled like a constellation of lights against the darkening sky...",
      readingTime: 30,
      isPremium: false,
    },
    {
      storyId: 10,
      title: "Chapter One: The Heist",
      episodeNumber: 1,
      description: "Kira plans the impossible theft.",
      content: "The tower of Obsidian Corp pierced the smog-covered sky like a black needle. Kira adjusted her goggles, the augmented reality display painting the building with thermal highlights. Three guards on the roof, two patrolling the perimeter, and one very expensive security system standing between her and the prototype...",
      readingTime: 22,
      isPremium: false,
    },
  ]);

  console.log("Seed complete!");
  process.exit(0);
}

seed().catch(console.error);
