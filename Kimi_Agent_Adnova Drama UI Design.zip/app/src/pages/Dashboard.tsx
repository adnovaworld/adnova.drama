import { useEffect } from "react";
import { Link, useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import {
  Heart,
  Bookmark,
  Clock,
  Bell,
  BookOpen,
} from "lucide-react";

export default function Dashboard() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate("/login");
    }
  }, [isLoading, isAuthenticated, navigate]);

  const { data: favorites } = trpc.user.favorites.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: bookmarks } = trpc.user.bookmarks.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: continueList } = trpc.user.continue.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: notifications } = trpc.user.notifications.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0C0E14] pt-24 flex items-center justify-center">
        <div className="animate-pulse text-white/40">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated) return null;

  return (
    <div className="min-h-screen bg-[#0C0E14] pt-24 pb-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-[1200px] mx-auto">
        {/* Profile Header */}
        <div className="flex items-center gap-4 mb-10">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#FF2D8D] to-[#FF6B9D] flex items-center justify-center text-2xl font-bold shrink-0">
            {user?.name?.[0] || user?.email?.[0] || "U"}
          </div>
          <div>
            <h1 className="text-2xl font-bold">{user?.name || "User"}</h1>
            <p className="text-white/50 text-sm">{user?.email}</p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-10">
          {[
            {
              icon: Heart,
              label: "Favorites",
              value: favorites?.length || 0,
            },
            {
              icon: Bookmark,
              label: "Bookmarks",
              value: bookmarks?.length || 0,
            },
            {
              icon: Clock,
              label: "Continue",
              value: continueList?.length || 0,
            },
            {
              icon: Bell,
              label: "Notifications",
              value: notifications?.filter((n) => !n.isRead).length || 0,
            },
          ].map((stat) => (
            <div
              key={stat.label}
              className="p-4 rounded-xl bg-white/[0.02] border border-white/5"
            >
              <stat.icon className="w-5 h-5 text-[#FF2D8D] mb-2" />
              <div className="text-2xl font-bold">{stat.value}</div>
              <div className="text-xs text-white/40">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Continue Watching */}
        {continueList && continueList.length > 0 && (
          <div className="mb-10">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <Clock className="w-5 h-5 text-[#FF2D8D]" />
              Continue
            </h2>
            <div className="space-y-3">
              {continueList.slice(0, 5).map((item: any) => (
                <Link
                  key={item.id}
                  to={`/story/${item.story?.slug}`}
                  className="flex items-center gap-4 p-3 rounded-xl hover:bg-white/5 transition-colors group"
                >
                  <div className="w-12 h-16 rounded-lg overflow-hidden shrink-0">
                    <img
                      src={item.story?.coverImage || "/assets/hero-poster.jpg"}
                      alt={item.story?.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm truncate group-hover:text-[#FF2D8D] transition-colors">
                      {item.story?.title}
                    </h4>
                    <p className="text-xs text-white/40">
                      {item.episode?.title}
                    </p>
                    <div className="w-full h-1 bg-white/10 rounded-full mt-2 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-[#FF2D8D] to-[#FF6B9D] rounded-full"
                        style={{ width: `${Math.min(item.progress, 100)}%` }}
                      />
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Favorites */}
        {favorites && favorites.length > 0 && (
          <div className="mb-10">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <Heart className="w-5 h-5 text-[#FF2D8D]" />
              Favorites
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {favorites.slice(0, 8).map((story: any) => (
                <Link
                  key={story.id}
                  to={`/story/${story.slug}`}
                  className="group"
                >
                  <div className="aspect-[2/3] rounded-xl overflow-hidden card-shadow mb-2">
                    <img
                      src={story.coverImage || "/assets/hero-poster.jpg"}
                      alt={story.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                  <h4 className="text-sm font-medium truncate group-hover:text-[#FF2D8D] transition-colors">
                    {story.title}
                  </h4>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Notifications */}
        {notifications && notifications.length > 0 && (
          <div>
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <Bell className="w-5 h-5 text-[#FF2D8D]" />
              Notifications
            </h2>
            <div className="space-y-2">
              {notifications.slice(0, 5).map((n) => (
                <div
                  key={n.id}
                  className={`p-3 rounded-xl ${
                    n.isRead
                      ? "bg-white/[0.01]"
                      : "bg-white/[0.03] border border-white/5"
                  }`}
                >
                  <p className="text-sm font-medium">{n.title}</p>
                  <p className="text-xs text-white/40">{n.message}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {(!favorites || favorites.length === 0) &&
          (!continueList || continueList.length === 0) && (
            <div className="text-center py-20">
              <BookOpen className="w-12 h-12 text-white/20 mx-auto mb-4" />
              <p className="text-white/40 mb-4">
                Start exploring stories to see them here
              </p>
              <Link
                to="/browse"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[#FF2D8D] to-[#FF6B9D] text-white font-medium"
              >
                Browse Stories
              </Link>
            </div>
          )}
      </div>
    </div>
  );
}
