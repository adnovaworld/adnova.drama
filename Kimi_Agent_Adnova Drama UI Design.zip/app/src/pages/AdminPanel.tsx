import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import {
  Users,
  BookOpen,
  Layers,
  CreditCard,
  Shield,
  Search,
  Star,
  Eye,
} from "lucide-react";

export default function AdminPanel() {
  const { isAuthenticated, isAdmin, isLoading } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<"overview" | "users" | "stories">("overview");
  const [userSearch, setUserSearch] = useState("");

  useEffect(() => {
    if (!isLoading && (!isAuthenticated || !isAdmin)) {
      navigate("/");
    }
  }, [isLoading, isAuthenticated, isAdmin, navigate]);

  const { data: dashboard } = trpc.admin.dashboard.useQuery(undefined, {
    enabled: isAdmin,
  });

  const { data: usersData } = trpc.admin.users.useQuery(
    { search: userSearch || undefined },
    { enabled: isAdmin && activeTab === "users" }
  );

  const { data: storiesData } = trpc.admin.stories.useQuery(
    {},
    { enabled: isAdmin && activeTab === "stories" }
  );

  const updateRole = trpc.admin.updateUserRole.useMutation({
    onSuccess: () => {
      utils.admin.users.invalidate();
    },
  });

  const featureStory = trpc.admin.featureStory.useMutation({
    onSuccess: () => {
      utils.admin.stories.invalidate();
    },
  });

  const utils = trpc.useUtils();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0C0E14] pt-24 flex items-center justify-center">
        <div className="animate-pulse text-white/40">Loading...</div>
      </div>
    );
  }

  if (!isAdmin) return null;

  const tabs = [
    { id: "overview" as const, label: "Overview", icon: Shield },
    { id: "users" as const, label: "Users", icon: Users },
    { id: "stories" as const, label: "Stories", icon: BookOpen },
  ];

  return (
    <div className="min-h-screen bg-[#0C0E14] pt-24 pb-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-[1200px] mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <Shield className="w-6 h-6 text-[#FF2D8D]" />
          <h1 className="text-3xl font-bold">Admin Panel</h1>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 border-b border-white/10">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors relative ${
                activeTab === tab.id
                  ? "text-[#FF2D8D]"
                  : "text-white/40 hover:text-white/60"
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
              {activeTab === tab.id && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#FF2D8D]" />
              )}
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === "overview" && dashboard && (
          <div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {[
                {
                  icon: Users,
                  label: "Total Users",
                  value: dashboard.totalUsers,
                },
                {
                  icon: BookOpen,
                  label: "Total Stories",
                  value: dashboard.totalStories,
                },
                {
                  icon: Layers,
                  label: "Total Episodes",
                  value: dashboard.totalEpisodes,
                },
                {
                  icon: CreditCard,
                  label: "Active Subs",
                  value: dashboard.activeSubscriptions,
                },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="p-5 rounded-xl bg-white/[0.02] border border-white/5"
                >
                  <stat.icon className="w-5 h-5 text-[#FF2D8D] mb-3" />
                  <div className="text-3xl font-bold">{stat.value}</div>
                  <div className="text-xs text-white/40 mt-1">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>

            {/* Quick Links */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button
                onClick={() => setActiveTab("users")}
                className="p-6 rounded-xl bg-white/[0.02] border border-white/5 hover:bg-white/[0.04] transition-colors text-left"
              >
                <Users className="w-6 h-6 text-[#FF2D8D] mb-3" />
                <h3 className="font-semibold mb-1">Manage Users</h3>
                <p className="text-sm text-white/40">
                  View and manage registered users
                </p>
              </button>
              <button
                onClick={() => setActiveTab("stories")}
                className="p-6 rounded-xl bg-white/[0.02] border border-white/5 hover:bg-white/[0.04] transition-colors text-left"
              >
                <BookOpen className="w-6 h-6 text-[#FF2D8D] mb-3" />
                <h3 className="font-semibold mb-1">Manage Stories</h3>
                <p className="text-sm text-white/40">
                  Feature stories and manage content
                </p>
              </button>
            </div>
          </div>
        )}

        {/* Users Tab */}
        {activeTab === "users" && (
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="relative flex-1 max-w-sm">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                <input
                  type="text"
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  placeholder="Search users..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm focus:outline-none focus:border-[#FF2D8D]/30"
                />
              </div>
            </div>

            <div className="space-y-2">
              {usersData?.users.map((u: any) => (
                <div
                  key={u.id}
                  className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.02] hover:bg-white/[0.03] transition-colors"
                >
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FF2D8D] to-[#FF6B9D] flex items-center justify-center text-sm font-bold shrink-0">
                    {u.name?.[0] || u.email?.[0] || "U"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">
                      {u.name || "Unnamed"}
                    </p>
                    <p className="text-xs text-white/40">{u.email}</p>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                      u.role === "admin"
                        ? "bg-[#FF2D8D]/20 text-[#FF2D8D]"
                        : "bg-white/5 text-white/40"
                    }`}
                  >
                    {u.role}
                  </span>
                  <button
                    onClick={() =>
                      updateRole.mutate({
                        userId: u.id,
                        role: u.role === "admin" ? "user" : "admin",
                      })
                    }
                    className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs hover:bg-white/10 transition-colors"
                  >
                    {u.role === "admin" ? "Demote" : "Promote"}
                  </button>
                </div>
              ))}
            </div>

            {(!usersData?.users || usersData.users.length === 0) && (
              <div className="text-center py-12">
                <p className="text-white/40">No users found</p>
              </div>
            )}
          </div>
        )}

        {/* Stories Tab */}
        {activeTab === "stories" && (
          <div>
            <div className="space-y-2">
              {storiesData?.stories.map((story: any) => (
                <div
                  key={story.id}
                  className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.02] hover:bg-white/[0.03] transition-colors"
                >
                  <div className="w-12 h-16 rounded-lg overflow-hidden shrink-0">
                    <img
                      src={story.coverImage || "/assets/hero-poster.jpg"}
                      alt={story.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">
                      {story.title}
                    </p>
                    <div className="flex items-center gap-3 text-xs text-white/40 mt-0.5">
                      <span>{story.type}</span>
                      <span>{story.category?.name}</span>
                      <span className="flex items-center gap-1">
                        <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                        {story.rating}
                      </span>
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        {(story.totalViews / 1000).toFixed(0)}K
                      </span>
                    </div>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded-full text-xs ${
                      story.isFeatured
                        ? "bg-[#FF2D8D]/20 text-[#FF2D8D]"
                        : "bg-white/5 text-white/40"
                    }`}
                  >
                    {story.isFeatured ? "Featured" : "Standard"}
                  </span>
                  <button
                    onClick={() =>
                      featureStory.mutate({
                        storyId: story.id,
                        featured: !story.isFeatured,
                      })
                    }
                    className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs hover:bg-white/10 transition-colors"
                  >
                    {story.isFeatured ? "Unfeature" : "Feature"}
                  </button>
                </div>
              ))}
            </div>

            {(!storiesData?.stories || storiesData.stories.length === 0) && (
              <div className="text-center py-12">
                <p className="text-white/40">No stories found</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
