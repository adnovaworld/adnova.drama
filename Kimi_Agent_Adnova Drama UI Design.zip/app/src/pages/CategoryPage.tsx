import { useParams, Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { Star, Eye } from "lucide-react";

export default function CategoryPage() {
  const { slug } = useParams<{ slug: string }>();
  const { data: category, isLoading } = trpc.category.getBySlug.useQuery(
    { slug: slug || "" },
    { enabled: !!slug }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0C0E14] pt-24 flex items-center justify-center">
        <div className="animate-pulse text-white/40">Loading...</div>
      </div>
    );
  }

  if (!category) {
    return (
      <div className="min-h-screen bg-[#0C0E14] pt-24 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Category not found</h2>
          <Link to="/browse" className="text-[#FF2D8D] hover:underline">
            Browse all stories
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0C0E14] pt-24 pb-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-[1440px] mx-auto">
        {/* Category Header */}
        <div className="relative h-48 sm:h-64 rounded-2xl overflow-hidden mb-10">
          {category.image && (
            <img
              src={category.image}
              alt={category.name}
              className="w-full h-full object-cover"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0C0E14] via-[#0C0E14]/60 to-transparent" />
          <div className="absolute inset-0 flex items-end p-6 sm:p-10">
            <div>
              <h1 className="text-3xl sm:text-4xl font-bold mb-2">
                {category.name}
              </h1>
              <p className="text-white/60 text-sm sm:text-base max-w-xl">
                {category.description}
              </p>
            </div>
          </div>
        </div>

        {/* Stories Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 sm:gap-6">
          {category.stories?.map((story: any) => (
            <Link
              key={story.id}
              to={`/story/${story.slug}`}
              className="group"
            >
              <div className="relative aspect-[2/3] rounded-xl overflow-hidden card-shadow mb-3">
                <img
                  src={story.coverImage || "/assets/hero-poster.jpg"}
                  alt={story.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                {story.isPremium && (
                  <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-[#FF2D8D] text-[10px] font-semibold">
                    PREMIUM
                  </div>
                )}
              </div>
              <h3 className="font-medium text-sm truncate group-hover:text-[#FF2D8D] transition-colors">
                {story.title}
              </h3>
              <div className="flex items-center gap-2 mt-1">
                <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                <span className="text-xs text-white/50">{story.rating}</span>
                <Eye className="w-3 h-3 text-white/30 ml-1" />
                <span className="text-xs text-white/30">
                  {(story.totalViews / 1000).toFixed(0)}K
                </span>
              </div>
            </Link>
          ))}
        </div>

        {(!category.stories || category.stories.length === 0) && (
          <div className="text-center py-20">
            <p className="text-white/40 mb-4">
              No stories in this category yet.
            </p>
            <Link
              to="/browse"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[#FF2D8D] to-[#FF6B9D] text-white font-medium"
            >
              Browse All Stories
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
