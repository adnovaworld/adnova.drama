import { useSearchParams, Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { Star, Eye, Search } from "lucide-react";

export default function SearchResults() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get("q") || "";

  const { data, isLoading } = trpc.story.search.useQuery(
    { query, limit: 50 },
    { enabled: query.length > 0 }
  );

  return (
    <div className="min-h-screen bg-[#0C0E14] pt-24 pb-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-[1440px] mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold mb-2">
            Search Results
          </h1>
          <p className="text-white/50">
            {query ? `Searching for "${query}"` : "Enter a search term"}
          </p>
        </div>

        {!query && (
          <div className="text-center py-20">
            <Search className="w-12 h-12 text-white/20 mx-auto mb-4" />
            <p className="text-white/40">
              Use the search bar to find stories
            </p>
          </div>
        )}

        {isLoading && (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="aspect-[2/3] rounded-xl bg-white/5 mb-3" />
                <div className="h-4 bg-white/5 rounded w-3/4 mb-2" />
                <div className="h-3 bg-white/5 rounded w-1/2" />
              </div>
            ))}
          </div>
        )}

        {data && data.length === 0 && query && (
          <div className="text-center py-20">
            <p className="text-white/40 mb-4">
              No stories found for "{query}"
            </p>
            <Link
              to="/browse"
              className="text-[#FF2D8D] hover:underline"
            >
              Browse all stories
            </Link>
          </div>
        )}

        {data && data.length > 0 && (
          <>
            <p className="text-sm text-white/40 mb-6">
              Found {data.length} result{data.length !== 1 ? "s" : ""}
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 sm:gap-6">
              {data.map((story) => (
                <Link
                  key={story.id}
                  to={`/story/${story.slug}`}
                  className="group"
                >
                  <div className="relative aspect-[2/3] rounded-xl overflow-hidden card-shadow mb-3">
                    <img
                      src={story.coverImage || "/assets/hero-poster.jpg"}
                      alt={story.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                    {story.isPremium && (
                      <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-[#FF2D8D] text-[10px] font-semibold">
                        PREMIUM
                      </div>
                    )}
                  </div>
                  <h3 className="font-medium text-sm truncate group-hover:text-[#FF2D8D] transition-colors">
                    {story.title}
                  </h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                    <span className="text-xs text-white/50">{story.rating}</span>
                    <Eye className="w-3 h-3 text-white/30 ml-1" />
                    <span className="text-xs text-white/30">
                      {((story.totalViews || 0) / 1000).toFixed(0)}K
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
