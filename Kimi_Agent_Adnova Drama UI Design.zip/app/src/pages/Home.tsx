import { useEffect, useRef } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";

import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import {
  Headphones,
  BookOpen,
  FileText,
  Play,
  Star,
  Eye,
  ChevronRight,
  Sparkles,
  Monitor,
  Tablet,
  Smartphone,
  ArrowRight,
} from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

export default function Home() {
  const { data: trendingStories } = trpc.story.trending.useQuery({ limit: 8 });
  // featuredStories available via API
  const { data: categories } = trpc.category.list.useQuery();
  const { data: audioStories } = trpc.story.list.useQuery({
    type: "audio",
    limit: 6,
  });
  const { data: comicStories } = trpc.story.list.useQuery({
    type: "comic",
    limit: 6,
  });
  const { data: textStories } = trpc.story.list.useQuery({
    type: "text",
    limit: 6,
  });

  const heroRef = useRef<HTMLDivElement>(null);
  const sectionsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Hero entrance animation
      gsap.fromTo(
        ".hero-card",
        { opacity: 0, y: 80, rotateX: 35 },
        {
          opacity: 1,
          y: 0,
          rotateX: 0,
          duration: 1.2,
          stagger: 0.15,
          ease: "power3.out",
        }
      );

      gsap.fromTo(
        ".hero-text",
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          stagger: 0.1,
          delay: 0.5,
          ease: "power2.out",
        }
      );

      // Scroll-triggered sections
      sectionsRef.current.forEach((section) => {
        if (!section) return;
        gsap.fromTo(
          section.querySelectorAll(".reveal-item"),
          { opacity: 0, y: 50 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            stagger: 0.1,
            ease: "power2.out",
            scrollTrigger: {
              trigger: section,
              start: "top 80%",
              toggleActions: "play none none reverse",
            },
          }
        );
      });
    });

    return () => ctx.revert();
  }, []);

  const setSectionRef = (index: number) => (el: HTMLDivElement | null) => {
    sectionsRef.current[index] = el;
  };

  return (
    <div className="bg-[#0C0E14]">
      {/* ── HERO SECTION ── */}
      <section
        ref={heroRef}
        className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden pt-20"
      >
        <div className="spotlight absolute inset-0 pointer-events-none" />

        {/* Decorative rings */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-[60vw] h-[60vw] max-w-[800px] max-h-[800px] rounded-full border border-white/5 animate-[spin_60s_linear_infinite]" />
          <div className="absolute w-[40vw] h-[40vw] max-w-[500px] max-h-[500px] rounded-full border border-white/[0.03] animate-[spin_40s_linear_infinite_reverse]" />
        </div>

        {/* 3D Card Composition */}
        <div className="perspective-1100 relative z-10 flex items-center justify-center gap-4 sm:gap-6 lg:gap-10 px-4 mb-8">
          {/* Left Card */}
          <div
            className="hero-card hidden sm:block w-[22vw] max-w-[280px] aspect-[2/3] rounded-2xl overflow-hidden card-shadow preserve-3d"
            style={{ transform: "rotateY(28deg) translateZ(-120px)" }}
          >
            <img
              src="/assets/card-fantasy-02.jpg"
              alt="Fantasy"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          </div>

          {/* Center Hero Card */}
          <div
            className="hero-card w-[40vw] sm:w-[32vw] max-w-[420px] aspect-[2/3] rounded-2xl overflow-hidden card-shadow preserve-3d relative"
            style={{ transform: "translateZ(80px)" }}
          >
            <img
              src="/assets/hero-poster.jpg"
              alt="Featured Story"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4 right-4">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#FF2D8D]/20 text-[#FF2D8D] text-xs font-medium mb-2">
                <Star className="w-3 h-3" />
                Featured
              </span>
              <h3 className="text-white font-semibold text-sm sm:text-base">
                The Shadow Heir
              </h3>
            </div>
          </div>

          {/* Right Card */}
          <div
            className="hero-card hidden sm:block w-[22vw] max-w-[280px] aspect-[2/3] rounded-2xl overflow-hidden card-shadow preserve-3d"
            style={{ transform: "rotateY(-28deg) translateZ(-120px)" }}
          >
            <img
              src="/assets/card-fantasy-01.jpg"
              alt="Fantasy"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          </div>
        </div>

        {/* Hero Text */}
        <div className="relative z-10 text-center px-4 max-w-3xl mx-auto">
          <h1 className="hero-text text-4xl sm:text-5xl lg:text-7xl font-bold tracking-tight mb-4">
            Stories That{" "}
            <span className="bg-gradient-to-r from-[#FF2D8D] to-[#FF6B9D] bg-clip-text text-transparent">
              Come Alive
            </span>
          </h1>
          <p className="hero-text text-white/60 text-base sm:text-lg max-w-xl mx-auto mb-8">
            Audio dramas, comics, and novels — personalized, immersive, and
            always on.
          </p>
          <div className="hero-text flex flex-wrap items-center justify-center gap-4">
            <Link
              to="/browse"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[#FF2D8D] to-[#FF6B9D] text-white font-medium hover:opacity-90 transition-opacity"
            >
              Explore Library
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/browse?type=audio"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white/5 border border-white/10 text-white font-medium hover:bg-white/10 transition-colors"
            >
              <Play className="w-4 h-4" />
              Start Listening
            </Link>
          </div>
        </div>
      </section>

      {/* ── CATEGORY SHOWCASE ── */}
      <section ref={setSectionRef(0)} className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-[1440px] mx-auto">
          <div className="text-center mb-12">
            <h2 className="reveal-item text-3xl sm:text-4xl font-bold mb-3">
              Pick Your Format
            </h2>
            <p className="reveal-item text-white/50">
              Choose how you want to experience stories
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              {
                icon: Headphones,
                title: "Audio Dramas",
                desc: "Immersive soundscapes with professional voice acting",
                image: "/assets/poster-thriller-closeup.jpg",
                link: "/browse?type=audio",
                color: "from-purple-500/20",
              },
              {
                icon: BookOpen,
                title: "Comics",
                desc: "Stunning visuals with gripping narratives",
                image: "/assets/card-comics-04.jpg",
                link: "/browse?type=comic",
                color: "from-blue-500/20",
              },
              {
                icon: FileText,
                title: "Text Stories",
                desc: "Rich narratives that spark your imagination",
                image: "/assets/card-fantasy-01.jpg",
                link: "/browse?type=text",
                color: "from-emerald-500/20",
              },
            ].map((item, i) => (
              <Link
                key={i}
                to={item.link}
                className="reveal-item group relative aspect-[4/3] rounded-2xl overflow-hidden card-shadow"
              >
                <img
                  src={item.image}
                  alt={item.title}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div
                  className={`absolute inset-0 bg-gradient-to-t ${item.color} via-black/40 to-black/80`}
                />
                <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
                  <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-sm flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <item.icon className="w-6 h-6 text-[#FF2D8D]" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                  <p className="text-sm text-white/60">{item.desc}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── TRENDING STORIES ── */}
      <section ref={setSectionRef(1)} className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-[1440px] mx-auto">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="reveal-item text-3xl sm:text-4xl font-bold mb-1">
                Trending Stories
              </h2>
              <p className="reveal-item text-white/50 text-sm">
                Most popular right now
              </p>
            </div>
            <Link
              to="/browse"
              className="reveal-item inline-flex items-center gap-1 text-sm text-[#FF2D8D] hover:underline"
            >
              View All <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {trendingStories?.map((story) => (
              <StoryCard
                key={story.id}
                story={story}
                className="reveal-item"
              />
            ))}
          </div>
        </div>
      </section>

      {/* ── PLATFORM OVERVIEW ── */}
      <section ref={setSectionRef(2)} className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-[1440px] mx-auto">
          <div className="reveal-item glass-panel rounded-3xl p-8 sm:p-12 lg:p-16 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-bl from-indigo-500/10 to-transparent rounded-full blur-3xl pointer-events-none" />
            <div className="relative z-10 max-w-2xl">
              <h2 className="text-3xl sm:text-4xl font-bold mb-4 leading-tight">
                Audio dramas, comics, text stories — plus the next evolution:{" "}
                <span className="text-[#FF2D8D]">AI video</span>.
              </h2>
              <p className="text-white/60 mb-8 text-base sm:text-lg">
                Discover a growing library of worlds. Save episodes, follow
                series, and get recommendations tuned to your taste.
              </p>
              <Link
                to="/browse"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[#FF2D8D] to-[#FF6B9D] text-white font-medium hover:opacity-90 transition-opacity"
              >
                Browse All Stories
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── AI VIDEO SECTION ── */}
      <section ref={setSectionRef(3)} className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-[1440px] mx-auto">
          <div className="text-center mb-12">
            <h2 className="reveal-item text-3xl sm:text-4xl font-bold mb-3">
              AI Video Stories
            </h2>
            <p className="reveal-item text-white/50">
              Cinematic moments, generated for you
            </p>
          </div>
          <div className="reveal-item relative aspect-video max-w-4xl mx-auto rounded-2xl overflow-hidden card-shadow group cursor-pointer">
            <img
              src="/assets/ai-cover-neon.jpg"
              alt="AI Video Stories"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="w-20 h-20 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Play className="w-8 h-8 text-white ml-1" />
              </div>
              <span className="text-2xl font-bold mb-2">Coming Soon</span>
              <p className="text-white/60 text-sm">
                AI-generated cinematic experiences
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ── AUDIO STORIES ── */}
      <section ref={setSectionRef(4)} className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-[1440px] mx-auto">
          <div className="flex items-center justify-between mb-10">
            <div className="flex items-center gap-3">
              <Headphones className="w-6 h-6 text-[#FF2D8D]" />
              <h2 className="reveal-item text-3xl sm:text-4xl font-bold">
                Audio Dramas
              </h2>
            </div>
            <Link
              to="/browse?type=audio"
              className="reveal-item inline-flex items-center gap-1 text-sm text-[#FF2D8D] hover:underline"
            >
              View All <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-6">
            {audioStories?.stories.map((story) => (
              <StoryCard
                key={story.id}
                story={story}
                compact
                className="reveal-item"
              />
            ))}
          </div>
        </div>
      </section>

      {/* ── COMICS ── */}
      <section ref={setSectionRef(5)} className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-[1440px] mx-auto">
          <div className="flex items-center justify-between mb-10">
            <div className="flex items-center gap-3">
              <BookOpen className="w-6 h-6 text-[#FF2D8D]" />
              <h2 className="reveal-item text-3xl sm:text-4xl font-bold">
                Top Comics
              </h2>
            </div>
            <Link
              to="/browse?type=comic"
              className="reveal-item inline-flex items-center gap-1 text-sm text-[#FF2D8D] hover:underline"
            >
              View All <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {comicStories?.stories.map((story) => (
              <StoryCard
                key={story.id}
                story={story}
                className="reveal-item"
              />
            ))}
          </div>
        </div>
      </section>

      {/* ── TEXT STORIES ── */}
      <section ref={setSectionRef(6)} className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-[1440px] mx-auto">
          <div className="flex items-center justify-between mb-10">
            <div className="flex items-center gap-3">
              <FileText className="w-6 h-6 text-[#FF2D8D]" />
              <h2 className="reveal-item text-3xl sm:text-4xl font-bold">
                Best Text Stories
              </h2>
            </div>
            <Link
              to="/browse?type=text"
              className="reveal-item inline-flex items-center gap-1 text-sm text-[#FF2D8D] hover:underline"
            >
              View All <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {textStories?.stories.map((story) => (
              <StoryCardWide
                key={story.id}
                story={story}
                className="reveal-item"
              />
            ))}
          </div>
        </div>
      </section>

      {/* ── CATEGORIES ── */}
      <section ref={setSectionRef(7)} className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-[1440px] mx-auto">
          <h2 className="reveal-item text-3xl sm:text-4xl font-bold mb-10">
            Explore Genres
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
            {categories?.map((cat) => (
              <Link
                key={cat.id}
                to={`/category/${cat.slug}`}
                className="reveal-item group relative aspect-[16/9] rounded-xl overflow-hidden"
              >
                {cat.image && (
                  <img
                    src={cat.image}
                    alt={cat.name}
                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                )}
                <div className="absolute inset-0 bg-black/50 group-hover:bg-black/40 transition-colors" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="font-semibold text-sm">{cat.name}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── CROSS PLATFORM ── */}
      <section ref={setSectionRef(8)} className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-[1440px] mx-auto text-center">
          <h2 className="reveal-item text-3xl sm:text-4xl font-bold mb-4">
            Available Everywhere
          </h2>
          <p className="reveal-item text-white/50 mb-12 max-w-lg mx-auto">
            Continue your stories seamlessly across all your devices
          </p>
          <div className="reveal-item flex items-center justify-center gap-8 sm:gap-16">
            <div className="flex flex-col items-center gap-3 group">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-white/10 transition-colors">
                <Monitor className="w-7 h-7 sm:w-8 sm:h-8 text-white/60 group-hover:text-[#FF2D8D] transition-colors" />
              </div>
              <span className="text-xs text-white/40 font-mono">WEB</span>
            </div>
            <div className="flex flex-col items-center gap-3 group">
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-white/10 transition-colors">
                <Tablet className="w-6 h-6 sm:w-7 sm:h-7 text-white/60 group-hover:text-[#FF2D8D] transition-colors" />
              </div>
              <span className="text-xs text-white/40 font-mono">TABLET</span>
            </div>
            <div className="flex flex-col items-center gap-3 group">
              <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-white/10 transition-colors">
                <Smartphone className="w-5 h-5 sm:w-6 sm:h-6 text-white/60 group-hover:text-[#FF2D8D] transition-colors" />
              </div>
              <span className="text-xs text-white/40 font-mono">MOBILE</span>
            </div>
          </div>
        </div>
      </section>

      {/* ── FOOTER CTA ── */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-[1440px] mx-auto">
          <div className="glass-panel rounded-3xl p-8 sm:p-12 text-center relative overflow-hidden">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-gradient-to-b from-[#FF2D8D]/10 to-transparent blur-3xl pointer-events-none" />
            <div className="relative z-10">
              <Sparkles className="w-10 h-10 text-[#FF2D8D] mx-auto mb-4" />
              <h2 className="text-3xl sm:text-4xl font-bold mb-4">
                Get the App
              </h2>
              <p className="text-white/60 mb-8 max-w-md mx-auto">
                Download Adnova Drama and carry thousands of stories in your
                pocket.
              </p>
              <div className="flex flex-wrap items-center justify-center gap-4">
                <button className="px-6 py-3 rounded-xl bg-white text-black font-medium text-sm hover:bg-white/90 transition-colors">
                  App Store
                </button>
                <button className="px-6 py-3 rounded-xl bg-white text-black font-medium text-sm hover:bg-white/90 transition-colors">
                  Google Play
                </button>
              </div>
            </div>
          </div>

          {/* Footer */}
          <footer className="mt-20 pt-10 border-t border-white/5">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-8 mb-10">
              <div>
                <h4 className="font-semibold mb-4 text-sm">Discover</h4>
                <div className="flex flex-col gap-2">
                  <Link to="/browse?type=audio" className="text-sm text-white/40 hover:text-white transition-colors">Audio</Link>
                  <Link to="/browse?type=comic" className="text-sm text-white/40 hover:text-white transition-colors">Comics</Link>
                  <Link to="/browse?type=text" className="text-sm text-white/40 hover:text-white transition-colors">Stories</Link>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-4 text-sm">Company</h4>
                <div className="flex flex-col gap-2">
                  <span className="text-sm text-white/40">About</span>
                  <span className="text-sm text-white/40">Careers</span>
                  <span className="text-sm text-white/40">Press</span>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-4 text-sm">Support</h4>
                <div className="flex flex-col gap-2">
                  <span className="text-sm text-white/40">Help Center</span>
                  <span className="text-sm text-white/40">Contact</span>
                  <span className="text-sm text-white/40">Privacy</span>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-4 text-sm">Premium</h4>
                <div className="flex flex-col gap-2">
                  <span className="text-sm text-white/40">Plans</span>
                  <span className="text-sm text-white/40">Gift Cards</span>
                </div>
              </div>
            </div>
            <div className="text-center text-white/20 text-xs">
              2024 Adnova Drama. All rights reserved.
            </div>
          </footer>
        </div>
      </section>
    </div>
  );
}

// ── Story Card Component ──
function StoryCard({
  story,
  compact,
  className,
}: {
  story: any;
  compact?: boolean;
  className?: string;
}) {
  return (
    <Link
      to={`/story/${story.slug}`}
      className={`group block ${className || ""}`}
    >
      <div
        className={`relative rounded-xl overflow-hidden card-shadow mb-3 ${
          compact ? "aspect-[3/4]" : "aspect-[2/3]"
        }`}
      >
        <img
          src={story.coverImage || "/assets/hero-poster.jpg"}
          alt={story.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        {story.isPremium && (
          <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-[#FF2D8D] text-[10px] font-semibold">
            PREMIUM
          </div>
        )}
        {story.type === "audio" && (
          <div className="absolute bottom-2 left-2 w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
            <Headphones className="w-4 h-4" />
          </div>
        )}
      </div>
      <h3 className="font-medium text-sm truncate group-hover:text-[#FF2D8D] transition-colors">
        {story.title}
      </h3>
      <p className="text-xs text-white/40">
        {story.category?.name} • {story.totalEpisodes} eps
      </p>
      <div className="flex items-center gap-2 mt-1">
        <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
        <span className="text-xs text-white/50">{story.rating}</span>
        <Eye className="w-3 h-3 text-white/30 ml-1" />
        <span className="text-xs text-white/30">
          {(story.totalViews / 1000).toFixed(0)}K
        </span>
      </div>
    </Link>
  );
}

// ── Wide Story Card ──
function StoryCardWide({
  story,
  className,
}: {
  story: any;
  className?: string;
}) {
  return (
    <Link
      to={`/story/${story.slug}`}
      className={`group flex gap-4 p-3 rounded-xl hover:bg-white/5 transition-colors ${
        className || ""
      }`}
    >
      <div className="w-24 sm:w-28 aspect-[2/3] rounded-lg overflow-hidden card-shadow shrink-0">
        <img
          src={story.coverImage || "/assets/hero-poster.jpg"}
          alt={story.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      <div className="flex-1 min-w-0 py-1">
        <h3 className="font-semibold mb-1 group-hover:text-[#FF2D8D] transition-colors truncate">
          {story.title}
        </h3>
        <p className="text-xs text-white/40 mb-2 line-clamp-2">
          {story.description}
        </p>
        <p className="text-xs text-white/30 mb-2">
          by {story.author}
        </p>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 text-xs text-white/40">
            <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
            {story.rating}
          </span>
          <span className="flex items-center gap-1 text-xs text-white/40">
            <BookOpen className="w-3 h-3" />
            {story.totalEpisodes} eps
          </span>
          {story.isPremium && (
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#FF2D8D]/20 text-[#FF2D8D]">
              PREMIUM
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
