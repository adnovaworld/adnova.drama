import { useState } from "react";
import { useSearchParams, Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { Headphones, BookOpen, FileText, Star, Eye, Filter } from "lucide-react";

const typeLabels: Record<string, { label: string; icon: typeof Headphones }> = {
  audio: { label: "Audio Dramas", icon: Headphones },
  comic: { label: "Comics", icon: BookOpen },
  text: { label: "Text Stories", icon: FileText },
};

const sortOptions = [
  { value: "trending", label: "Trending" },
  { value: "newest", label: "Newest" },
  { value: "rating", label: "Top Rated" },
  { value: "views", label: "Most Viewed" },
];

export default function Browse() {
  const [searchParams] = useSearchParams();
  const type = searchParams.get("type") as "audio" | "comic" | "text" | undefined;
  const [sort, setSort] = useState("trending");
  const [page, setPage] = useState(1);

  const { data, isLoading } = trpc.story.list.useQuery({
    type,
    sort: sort as any,
    page,
    limit: 24,
  });

  const typeInfo = type ? typeLabels[type] : null;
  const TypeIcon = typeInfo?.icon;

  return (
    <div className="min-h-screen bg-[#0C0E14] pt-24 pb-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-[1440px] mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            {TypeIcon && <TypeIcon className="w-6 h-6 text-[#FF2D8D]" />}
            <h1 className="text-3xl sm:text-4xl font-bold">
              {typeInfo?.label || "All Stories"}
            </h1>
          </div>
          <p className="text-white/50">
            {type
              ? `Browse our collection of ${typeInfo?.label.toLowerCase()}`
              : "Discover stories across all formats"}
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 mb-8">
          <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/5 border border-white/10">
            <Filter className="w-4 h-4 text-white/40" />
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              className="bg-transparent text-sm outline-none cursor-pointer"
            >
              {sortOptions.map((opt) => (
                <option key={opt.value} value={opt.value} className="bg-[#1A1D24]">
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          {!type && (
            <div className="flex gap-2">
              {(["audio", "comic", "text"] as const).map((t) => {
                const info = typeLabels[t];
                const Icon = info.icon;
                return (
                  <Link
                    key={t}
                    to={`/browse?type=${t}`}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-sm hover:bg-white/10 transition-colors"
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {info.label}
                  </Link>
                );
              })}
            </div>
          )}
        </div>

        {/* Stories Grid */}
        {isLoading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4 sm:gap-6">
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="aspect-[2/3] rounded-xl bg-white/5 mb-3" />
                <div className="h-4 bg-white/5 rounded w-3/4 mb-2" />
                <div className="h-3 bg-white/5 rounded w-1/2" />
              </div>
            ))}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4 sm:gap-6">
              {data?.stories.map((story) => (
                <Link
                  key={story.id}
                  to={`/story/${story.slug}`}
                  className="group"
                >
                  <div className="relative aspect-[2/3] rounded-xl overflow-hidden card-shadow mb-3">
                    <img
                      src={story.coverImage || "/assets/hero-poster.jpg"}
                      alt={story.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                    {story.isPremium && (
                      <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-[#FF2D8D] text-[10px] font-semibold">
                        PREMIUM
                      </div>
                    )}
                  </div>
                  <h3 className="font-medium text-sm truncate group-hover:text-[#FF2D8D] transition-colors">
                    {story.title}
                  </h3>
                  <p className="text-xs text-white/40">
                    {story.category?.name} • {story.totalEpisodes} eps
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                    <span className="text-xs text-white/50">{story.rating}</span>
                    <Eye className="w-3 h-3 text-white/30 ml-1" />
                    <span className="text-xs text-white/30">
                      {((story.totalViews || 0) / 1000).toFixed(0)}K
                    </span>
                  </div>
                </Link>
              ))}
            </div>

            {/* Pagination */}
            {data && data.total > 24 && (
              <div className="flex items-center justify-center gap-2 mt-12">
                <button
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  disabled={page === 1}
                  className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-sm disabled:opacity-30 hover:bg-white/10 transition-colors"
                >
                  Previous
                </button>
                <span className="text-sm text-white/40 px-4">
                  Page {page} of {Math.ceil(data.total / 24)}
                </span>
                <button
                  onClick={() => setPage((p) => p + 1)}
                  disabled={page >= Math.ceil(data.total / 24)}
                  className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-sm disabled:opacity-30 hover:bg-white/10 transition-colors"
                >
                  Next
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
