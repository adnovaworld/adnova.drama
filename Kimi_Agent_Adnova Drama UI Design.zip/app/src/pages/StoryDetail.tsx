import { useState } from "react";
import { useParams, Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import {
  Star,
  Eye,
  Heart,
  Share2,
  Play,
  BookOpen,
  Headphones,
  FileText,
  ChevronRight,
  Clock,
} from "lucide-react";

export default function StoryDetail() {
  const { slug } = useParams<{ slug: string }>();
  const { isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState<"episodes" | "reviews">("episodes");

  const { data: story, isLoading } = trpc.story.getBySlug.useQuery(
    { slug: slug || "" },
    { enabled: !!slug }
  );

  const { data: episodes } = trpc.episode.list.useQuery(
    { storyId: story?.id || 0 },
    { enabled: !!story?.id }
  );

  const { data: reviewData } = trpc.review.list.useQuery(
    { storyId: story?.id || 0 },
    { enabled: !!story?.id }
  );

  const toggleFav = trpc.user.toggleFavorite.useMutation({
    onSuccess: () => {
      utils.story.getBySlug.invalidate({ slug: slug || "" });
    },
  });

  const createReview = trpc.review.create.useMutation({
    onSuccess: () => {
      utils.review.list.invalidate({ storyId: story?.id || 0 });
      setReviewRating(0);
      setReviewComment("");
    },
  });

  const utils = trpc.useUtils();
  const [reviewRating, setReviewRating] = useState(0);
  const [reviewComment, setReviewComment] = useState("");

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0C0E14] pt-24 flex items-center justify-center">
        <div className="animate-pulse text-white/40">Loading story...</div>
      </div>
    );
  }

  if (!story) {
    return (
      <div className="min-h-screen bg-[#0C0E14] pt-24 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Story not found</h2>
          <Link to="/browse" className="text-[#FF2D8D] hover:underline">
            Browse all stories
          </Link>
        </div>
      </div>
    );
  }

  const typeIcons = {
    audio: Headphones,
    comic: BookOpen,
    text: FileText,
    video: Play,
  };
  const TypeIcon = typeIcons[story.type as keyof typeof typeIcons] || BookOpen;

  return (
    <div className="min-h-screen bg-[#0C0E14]">
      {/* Hero Banner */}
      <div className="relative h-[50vh] sm:h-[60vh] overflow-hidden">
        <img
          src={story.coverImage || "/assets/hero-poster.jpg"}
          alt={story.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0C0E14] via-[#0C0E14]/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0C0E14]/80 to-transparent" />
      </div>

      {/* Content */}
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 lg:px-8 -mt-32 relative z-10 pb-20">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Left: Cover + Actions */}
          <div className="lg:w-72 shrink-0">
            <div className="aspect-[2/3] rounded-2xl overflow-hidden card-shadow mb-4">
              <img
                src={story.coverImage || "/assets/hero-poster.jpg"}
                alt={story.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  if (isAuthenticated) {
                    toggleFav.mutate({ storyId: story.id });
                  }
                }}
                className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
              >
                <Heart className="w-4 h-4" />
                <span className="text-sm">Save</span>
              </button>
              <button className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
                <Share2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Right: Info */}
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-3">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-xs">
                <TypeIcon className="w-3 h-3" />
                {story.type}
              </span>
              {story.isPremium && (
                <span className="px-2 py-0.5 rounded-full bg-[#FF2D8D]/20 text-[#FF2D8D] text-xs font-semibold">
                  PREMIUM
                </span>
              )}
              <span
                className={`px-2 py-0.5 rounded-full text-xs ${
                  story.status === "ongoing"
                    ? "bg-green-500/20 text-green-400"
                    : story.status === "completed"
                    ? "bg-blue-500/20 text-blue-400"
                    : "bg-yellow-500/20 text-yellow-400"
                }`}
              >
                {story.status}
              </span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-3">
              {story.title}
            </h1>

            <p className="text-white/60 mb-4">by {story.author}</p>

            <p className="text-white/70 text-base sm:text-lg leading-relaxed mb-6 max-w-2xl">
              {story.description}
            </p>

            <div className="flex flex-wrap items-center gap-4 mb-8">
              <div className="flex items-center gap-1.5">
                <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                <span className="font-semibold">{story.rating}</span>
              </div>
              <div className="flex items-center gap-1.5 text-white/50">
                <Eye className="w-4 h-4" />
                <span className="text-sm">
                  {((story.totalViews || 0) / 1000).toFixed(1)}K views
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-white/50">
                <BookOpen className="w-4 h-4" />
                <span className="text-sm">{story.totalEpisodes} episodes</span>
              </div>
              <div className="text-white/50 text-sm">
                {story.category?.name}
              </div>
            </div>

            {story.tags && (
              <div className="flex flex-wrap gap-2 mb-8">
                {(story.tags as string[]).map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs text-white/50"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            )}

            {/* CTA */}
            <Link
              to={
                episodes?.episodes[0]
                  ? `/story/${story.slug}?episode=${episodes.episodes[0].id}`
                  : "#"
              }
              className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-[#FF2D8D] to-[#FF6B9D] text-white font-semibold hover:opacity-90 transition-opacity mb-10"
            >
              <Play className="w-5 h-5" />
              {story.type === "audio"
                ? "Start Listening"
                : story.type === "comic"
                ? "Start Reading"
                : "Start Reading"}
            </Link>

            {/* Tabs */}
            <div className="flex gap-6 border-b border-white/10 mb-6">
              <button
                onClick={() => setActiveTab("episodes")}
                className={`pb-3 text-sm font-medium transition-colors relative ${
                  activeTab === "episodes"
                    ? "text-[#FF2D8D]"
                    : "text-white/40 hover:text-white/60"
                }`}
              >
                Episodes ({story.totalEpisodes})
                {activeTab === "episodes" && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#FF2D8D]" />
                )}
              </button>
              <button
                onClick={() => setActiveTab("reviews")}
                className={`pb-3 text-sm font-medium transition-colors relative ${
                  activeTab === "reviews"
                    ? "text-[#FF2D8D]"
                    : "text-white/40 hover:text-white/60"
                }`}
              >
                Reviews ({reviewData?.total || 0})
                {activeTab === "reviews" && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#FF2D8D]" />
                )}
              </button>
            </div>

            {/* Episodes Tab */}
            {activeTab === "episodes" && (
              <div className="space-y-2">
                {episodes?.episodes.map((ep) => (
                  <div
                    key={ep.id}
                    className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.02] hover:bg-white/5 transition-colors group cursor-pointer"
                  >
                    <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center shrink-0 group-hover:bg-[#FF2D8D]/20 transition-colors">
                      <span className="text-sm font-semibold text-white/40 group-hover:text-[#FF2D8D]">
                        {ep.episodeNumber}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-sm truncate group-hover:text-[#FF2D8D] transition-colors">
                        {ep.title}
                      </h4>
                      <p className="text-xs text-white/40 truncate">
                        {ep.description}
                      </p>
                    </div>
                    <div className="flex items-center gap-3 text-white/30 shrink-0">
                      {ep.audioDuration && (
                        <span className="flex items-center gap-1 text-xs">
                          <Clock className="w-3 h-3" />
                          {Math.floor(ep.audioDuration / 60)}m
                        </span>
                      )}
                      {ep.readingTime && (
                        <span className="flex items-center gap-1 text-xs">
                          <Clock className="w-3 h-3" />
                          {ep.readingTime}m read
                        </span>
                      )}
                      {ep.isPremium && (
                        <span className="px-2 py-0.5 rounded-full bg-[#FF2D8D]/20 text-[#FF2D8D] text-[10px]">
                          PREMIUM
                        </span>
                      )}
                    </div>
                    <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-[#FF2D8D] transition-colors shrink-0" />
                  </div>
                ))}
              </div>
            )}

            {/* Reviews Tab */}
            {activeTab === "reviews" && (
              <div>
                {/* Review Summary */}
                <div className="flex items-center gap-4 mb-6 p-4 rounded-xl bg-white/[0.02]">
                  <div className="text-4xl font-bold">
                    {reviewData?.averageRating.toFixed(1) || "0.0"}
                  </div>
                  <div>
                    <div className="flex gap-0.5 mb-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-4 h-4 ${
                            star <= Math.round(reviewData?.averageRating || 0)
                              ? "text-yellow-400 fill-yellow-400"
                              : "text-white/20"
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-xs text-white/40">
                      {reviewData?.total || 0} reviews
                    </p>
                  </div>
                </div>

                {/* Write Review */}
                {isAuthenticated && (
                  <div className="mb-6 p-4 rounded-xl bg-white/[0.02] border border-white/5">
                    <h4 className="font-medium mb-3">Write a Review</h4>
                    <div className="flex gap-1 mb-3">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          onClick={() => setReviewRating(star)}
                          className="p-1"
                        >
                          <Star
                            className={`w-5 h-5 ${
                              star <= reviewRating
                                ? "text-yellow-400 fill-yellow-400"
                                : "text-white/20"
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                    <textarea
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      placeholder="Share your thoughts..."
                      className="w-full p-3 rounded-lg bg-white/5 border border-white/10 text-sm resize-none h-24 focus:outline-none focus:border-[#FF2D8D]/30"
                    />
                    <button
                      onClick={() => {
                        if (reviewRating > 0) {
                          createReview.mutate({
                            storyId: story.id,
                            rating: reviewRating,
                            comment: reviewComment,
                          });
                        }
                      }}
                      className="mt-2 px-4 py-2 rounded-lg bg-gradient-to-r from-[#FF2D8D] to-[#FF6B9D] text-white text-sm font-medium hover:opacity-90 transition-opacity"
                    >
                      Submit Review
                    </button>
                  </div>
                )}

                {/* Reviews List */}
                <div className="space-y-4">
                  {reviewData?.reviews.map((review) => (
                    <div
                      key={review.id}
                      className="p-4 rounded-xl bg-white/[0.02]"
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#FF2D8D] to-[#FF6B9D] flex items-center justify-center text-xs font-bold">
                          {review.user?.name?.[0] || "U"}
                        </div>
                        <div>
                          <p className="text-sm font-medium">
                            {review.user?.name || "Anonymous"}
                          </p>
                          <div className="flex gap-0.5">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`w-3 h-3 ${
                                  star <= review.rating
                                    ? "text-yellow-400 fill-yellow-400"
                                    : "text-white/20"
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                      {review.comment && (
                        <p className="text-sm text-white/60 pl-11">
                          {review.comment}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
