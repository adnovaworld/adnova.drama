import { useState, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import {
  Search,
  Menu,
  X,
  Headphones,
  BookOpen,
  Zap,
  User,
  LogOut,
  Shield,
  Home,
  Sparkles,
} from "lucide-react";

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();
  const location = useLocation();
  const { isAuthenticated, isAdmin, logout } = useAuth();
  

  const { data: categories } = trpc.category.list.useQuery();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    setSearchOpen(false);
  }, [location.pathname]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
      setSearchOpen(false);
      setSearchQuery("");
    }
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? "bg-[rgba(12,14,20,0.92)] backdrop-blur-xl border-b border-white/5"
            : "bg-transparent"
        }`}
      >
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 shrink-0">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#FF2D8D] to-[#FF6B9D] flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold text-lg tracking-tight hidden sm:block">
                Adnova Drama
              </span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden lg:flex items-center gap-6">
              <Link
                to="/"
                className="text-sm text-white/70 hover:text-white transition-colors"
              >
                Home
              </Link>
              <Link
                to="/browse?type=audio"
                className="text-sm text-white/70 hover:text-white transition-colors flex items-center gap-1.5"
              >
                <Headphones className="w-3.5 h-3.5" />
                Audio
              </Link>
              <Link
                to="/browse?type=comic"
                className="text-sm text-white/70 hover:text-white transition-colors flex items-center gap-1.5"
              >
                <BookOpen className="w-3.5 h-3.5" />
                Comics
              </Link>
              <Link
                to="/browse?type=text"
                className="text-sm text-white/70 hover:text-white transition-colors flex items-center gap-1.5"
              >
                <Zap className="w-3.5 h-3.5" />
                Stories
              </Link>
              {categories?.slice(0, 5).map((cat) => (
                <Link
                  key={cat.id}
                  to={`/category/${cat.slug}`}
                  className="text-sm text-white/70 hover:text-white transition-colors"
                >
                  {cat.name}
                </Link>
              ))}
            </div>

            {/* Right Actions */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => setSearchOpen(!searchOpen)}
                className="p-2 rounded-lg hover:bg-white/5 transition-colors"
                aria-label="Search"
              >
                <Search className="w-5 h-5" />
              </button>

              {isAuthenticated ? (
                <div className="hidden sm:flex items-center gap-3">
                  <Link
                    to="/dashboard"
                    className="p-2 rounded-lg hover:bg-white/5 transition-colors"
                    title="Dashboard"
                  >
                    <User className="w-5 h-5" />
                  </Link>
                  {isAdmin && (
                    <Link
                      to="/admin"
                      className="p-2 rounded-lg hover:bg-white/5 transition-colors text-[#FF2D8D]"
                      title="Admin"
                    >
                      <Shield className="w-5 h-5" />
                    </Link>
                  )}
                  <button
                    onClick={logout}
                    className="p-2 rounded-lg hover:bg-white/5 transition-colors text-white/50 hover:text-white"
                    title="Logout"
                  >
                    <LogOut className="w-5 h-5" />
                  </button>
                </div>
              ) : (
                <Link
                  to="/login"
                  className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-[#FF2D8D] to-[#FF6B9D] text-white text-sm font-medium hover:opacity-90 transition-opacity"
                >
                  Sign In
                </Link>
              )}

              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="lg:hidden p-2 rounded-lg hover:bg-white/5 transition-colors"
                aria-label="Menu"
              >
                {menuOpen ? (
                  <X className="w-5 h-5" />
                ) : (
                  <Menu className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Search Overlay */}
      {searchOpen && (
        <div className="fixed inset-0 z-[60] bg-[rgba(12,14,20,0.97)] backdrop-blur-xl flex items-start justify-center pt-24 px-4">
          <div className="w-full max-w-2xl">
            <form onSubmit={handleSearch} className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
              <input
                type="text"
                autoFocus
                placeholder="Search stories, authors, genres..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-white/5 border border-white/10 rounded-2xl text-lg text-white placeholder:text-white/30 focus:outline-none focus:border-[#FF2D8D]/50"
              />
              <button
                type="button"
                onClick={() => setSearchOpen(false)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-white/40 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </form>
            <div className="mt-8">
              <p className="text-xs uppercase tracking-widest text-white/30 mb-4 font-mono">
                Popular Categories
              </p>
              <div className="flex flex-wrap gap-2">
                {categories?.slice(0, 8).map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => {
                      navigate(`/category/${cat.slug}`);
                      setSearchOpen(false);
                    }}
                    className="px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-sm transition-colors"
                  >
                    {cat.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="fixed inset-0 z-40 bg-[rgba(12,14,20,0.98)] backdrop-blur-xl pt-20 px-6 pb-8 lg:hidden">
          <div className="flex flex-col gap-4">
            <Link
              to="/"
              className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors"
            >
              <Home className="w-5 h-5 text-[#FF2D8D]" />
              <span className="text-lg">Home</span>
            </Link>
            <Link
              to="/browse?type=audio"
              className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors"
            >
              <Headphones className="w-5 h-5 text-[#FF2D8D]" />
              <span className="text-lg">Audio Dramas</span>
            </Link>
            <Link
              to="/browse?type=comic"
              className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors"
            >
              <BookOpen className="w-5 h-5 text-[#FF2D8D]" />
              <span className="text-lg">Comics</span>
            </Link>
            <Link
              to="/browse?type=text"
              className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors"
            >
              <Zap className="w-5 h-5 text-[#FF2D8D]" />
              <span className="text-lg">Text Stories</span>
            </Link>
            <div className="border-t border-white/10 my-2" />
            <p className="text-xs uppercase tracking-widest text-white/30 font-mono px-3">
              Categories
            </p>
            {categories?.map((cat) => (
              <Link
                key={cat.id}
                to={`/category/${cat.slug}`}
                className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors"
              >
                <span className="text-sm">{cat.name}</span>
              </Link>
            ))}
            {isAuthenticated && (
              <>
                <div className="border-t border-white/10 my-2" />
                <Link
                  to="/dashboard"
                  className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors"
                >
                  <User className="w-5 h-5 text-[#FF2D8D]" />
                  <span className="text-lg">My Dashboard</span>
                </Link>
                {isAdmin && (
                  <Link
                    to="/admin"
                    className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors"
                  >
                    <Shield className="w-5 h-5 text-[#FF2D8D]" />
                    <span className="text-lg">Admin Panel</span>
                  </Link>
                )}
                <button
                  onClick={logout}
                  className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors text-white/60"
                >
                  <LogOut className="w-5 h-5" />
                  <span className="text-lg">Logout</span>
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}
