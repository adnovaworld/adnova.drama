import { Outlet } from "react-router";
import Navigation from "./Navigation";

export default function Layout() {
  return (
    <div className="min-h-screen bg-[#0C0E14] text-white">
      <Navigation />
      <main>
        <Outlet />
      </main>
      <div className="noise-overlay" />
    </div>
  );
}
