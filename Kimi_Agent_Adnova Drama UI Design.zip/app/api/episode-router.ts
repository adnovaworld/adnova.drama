import { z } from "zod";
import { eq, and, asc } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { episodes } from "@db/schema";

export const episodeRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        storyId: z.number(),
        page: z.number().default(1),
        limit: z.number().default(50),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const offset = (input.page - 1) * input.limit;
      const items = await db.query.episodes.findMany({
        where: eq(episodes.storyId, input.storyId),
        orderBy: [asc(episodes.episodeNumber)],
        limit: input.limit,
        offset,
      });
      return { episodes: items, total: items.length };
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.query.episodes.findFirst({
        where: eq(episodes.id, input.id),
        with: { story: true },
      });
    }),

  next: publicQuery
    .input(
      z.object({
        storyId: z.number(),
        currentEpisodeNumber: z.number(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      return db.query.episodes.findFirst({
        where: and(
          eq(episodes.storyId, input.storyId),
          eq(episodes.episodeNumber, input.currentEpisodeNumber + 1)
        ),
      });
    }),
});
