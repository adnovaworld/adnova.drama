import { authRouter } from "./auth-router";
import { storyRouter } from "./story-router";
import { categoryRouter } from "./category-router";
import { episodeRouter } from "./episode-router";
import { userRouter } from "./user-router";
import { reviewRouter } from "./review-router";
import { adminRouter } from "./admin-router";
import { localAuthRouter } from "./local-auth-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  localAuth: localAuthRouter,
  story: storyRouter,
  category: categoryRouter,
  episode: episodeRouter,
  user: userRouter,
  review: reviewRouter,
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
