import { z } from "zod";
import { eq } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { categories } from "@db/schema";

export const categoryRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = (await import("./queries/connection")).getDb();
    return db.query.categories.findMany({
      orderBy: (categories, { asc }) => [asc(categories.sortOrder)],
    });
  }),

  getBySlug: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = (await import("./queries/connection")).getDb();
      return db.query.categories.findFirst({
        where: eq(categories.slug, input.slug),
        with: {
          stories: true,
        },
      });
    }),
});
