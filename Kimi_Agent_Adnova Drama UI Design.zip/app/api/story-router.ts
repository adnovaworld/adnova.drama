import { z } from "zod";
import { eq, desc, sql, or, like } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { stories, reviews } from "@db/schema";

export const storyRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        type: z.enum(["audio", "comic", "text", "video"]).optional(),
        categoryId: z.number().optional(),
        status: z.string().optional(),
        search: z.string().optional(),
        sort: z.enum(["trending", "newest", "rating", "views"]).default("trending"),
        page: z.number().default(1),
        limit: z.number().default(20),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const limit = input.limit || 20;
      const offset = ((input.page || 1) - 1) * limit;

      const conditions: any[] = [];
      if (input.type) conditions.push(eq(stories.type, input.type as "audio" | "comic" | "text" | "video"));
      if (input.categoryId) conditions.push(eq(stories.categoryId, input.categoryId));
      if (input.status) conditions.push(eq(stories.status, input.status as "ongoing" | "completed" | "coming_soon"));
      if (input.search) {
        conditions.push(
          or(
            like(stories.title, `%${input.search}%`),
            like(stories.description, `%${input.search}%`)
          )
        );
      }

      const where = conditions.length > 0 ? and(...conditions) : undefined;

      let orderBy;
      switch (input.sort) {
        case "newest":
          orderBy = desc(stories.createdAt);
          break;
        case "rating":
          orderBy = desc(stories.rating);
          break;
        case "views":
          orderBy = desc(stories.totalViews);
          break;
        default:
          orderBy = desc(stories.totalViews);
      }

      const items = await db.query.stories.findMany({
        where,
        orderBy,
        limit,
        offset,
        with: {
          category: true,
        },
      });

      const countResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(stories)
        .where(where);

      return {
        stories: items,
        total: Number(countResult[0]?.count || 0),
      };
    }),

  getBySlug: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const story = await db.query.stories.findFirst({
        where: eq(stories.slug, input.slug),
        with: {
          category: true,
          episodes: true,
        },
      });

      if (!story) return null;

      const storyReviews = await db.query.reviews.findMany({
        where: eq(reviews.storyId, story.id),
        with: { user: true },
        limit: 10,
      });

      return { ...story, reviews: storyReviews };
    }),

  trending: publicQuery
    .input(
      z.object({
        type: z.enum(["audio", "comic", "text", "video"]).optional(),
        limit: z.number().default(10),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions: any[] = [];
      if (input.type) conditions.push(eq(stories.type, input.type));
      const where = conditions.length > 0 ? and(...conditions) : undefined;

      return db.query.stories.findMany({
        where,
        orderBy: desc(stories.totalViews),
        limit: input.limit || 10,
        with: { category: true },
      });
    }),

  featured: publicQuery
    .input(z.object({ limit: z.number().default(10) }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.query.stories.findMany({
        where: eq(stories.isFeatured, true),
        orderBy: desc(stories.createdAt),
        limit: input.limit || 10,
        with: { category: true },
      });
    }),

  search: publicQuery
    .input(
      z.object({
        query: z.string(),
        type: z.string().optional(),
        limit: z.number().default(10),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions: any[] = [
        or(
          like(stories.title, `%${input.query}%`),
          like(stories.description, `%${input.query}%`)
        ),
      ];
      if (input.type) {
        conditions.push(eq(stories.type, input.type as "audio" | "comic" | "text" | "video"));
      }

      return db.query.stories.findMany({
        where: and(...conditions),
        limit: input.limit,
        with: { category: true },
      });
    }),
});

function and(...conditions: any[]) {
  return sql`(${conditions.join(" AND ")})`;
}
