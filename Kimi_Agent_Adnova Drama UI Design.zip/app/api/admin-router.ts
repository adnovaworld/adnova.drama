import { z } from "zod";
import { eq, desc, sql, like, or } from "drizzle-orm";
import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { users, stories, episodes, subscriptions } from "@db/schema";

export const adminRouter = createRouter({
  dashboard: adminQuery.query(async () => {
    const db = getDb();

    const totalUsers = await db
      .select({ count: sql<number>`count(*)` })
      .from(users);
    const totalStories = await db
      .select({ count: sql<number>`count(*)` })
      .from(stories);
    const totalEpisodes = await db
      .select({ count: sql<number>`count(*)` })
      .from(episodes);
    const activeSubs = await db
      .select({ count: sql<number>`count(*)` })
      .from(subscriptions)
      .where(eq(subscriptions.status, "active"));

    return {
      totalUsers: Number(totalUsers[0]?.count || 0),
      totalStories: Number(totalStories[0]?.count || 0),
      totalEpisodes: Number(totalEpisodes[0]?.count || 0),
      activeSubscriptions: Number(activeSubs[0]?.count || 0),
    };
  }),

  users: adminQuery
    .input(
      z.object({
        page: z.number().default(1),
        limit: z.number().default(20),
        search: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const limit = input.limit || 20;
      const offset = (input.page - 1) * limit;

      const where = input.search
        ? or(
            like(users.name, `%${input.search}%`),
            like(users.email, `%${input.search}%`)
          )
        : undefined;

      const items = await db.query.users.findMany({
        where,
        orderBy: [desc(users.createdAt)],
        limit,
        offset,
      });

      const countResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(users)
        .where(where);

      return { users: items, total: Number(countResult[0]?.count || 0) };
    }),

  stories: adminQuery
    .input(
      z.object({
        page: z.number().default(1),
        limit: z.number().default(20),
        type: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const limit = input.limit || 20;
      const offset = (input.page - 1) * limit;

      const where = input.type ? eq(stories.type, input.type as "audio" | "comic" | "text" | "video") : undefined;

      const items = await db.query.stories.findMany({
        where,
        orderBy: [desc(stories.createdAt)],
        limit,
        offset,
        with: { category: true },
      });

      const countResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(stories)
        .where(where);

      return { stories: items, total: Number(countResult[0]?.count || 0) };
    }),

  updateUserRole: adminQuery
    .input(
      z.object({
        userId: z.number(),
        role: z.enum(["user", "admin"]),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(users)
        .set({ role: input.role })
        .where(eq(users.id, input.userId));
      return { success: true };
    }),

  featureStory: adminQuery
    .input(
      z.object({
        storyId: z.number(),
        featured: z.boolean(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(stories)
        .set({ isFeatured: input.featured })
        .where(eq(stories.id, input.storyId));
      return { success: true };
    }),
});
