import { z } from "zod";
import { eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { users, localUsers } from "@db/schema";

async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + "adnova-salt-2024");
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

function generateToken(userId: number): string {
  const payload = { userId, exp: Date.now() + 30 * 24 * 60 * 60 * 1000 };
  return btoa(JSON.stringify(payload));
}

export const localAuthRouter = createRouter({
  register: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        email: z.string().email(),
        password: z.string().min(6),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const existing = await db.query.users.findFirst({
        where: eq(users.email, input.email),
      });
      if (existing) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "Email already registered",
        });
      }

      const [user] = await db.insert(users).values({
        name: input.name,
        email: input.email,
        role: "user",
      });

      const passwordHash = await hashPassword(input.password);
      await db.insert(localUsers).values({
        userId: Number(user.insertId),
        passwordHash,
      });

      const token = generateToken(Number(user.insertId));
      return { token, user: { id: Number(user.insertId), email: input.email, name: input.name } };
    }),

  login: publicQuery
    .input(
      z.object({
        email: z.string().email(),
        password: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const user = await db.query.users.findFirst({
        where: eq(users.email, input.email),
      });
      if (!user) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Invalid email or password",
        });
      }

      const localUser = await db.query.localUsers.findFirst({
        where: eq(localUsers.userId, user.id),
      });
      if (!localUser) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Invalid email or password",
        });
      }

      const passwordHash = await hashPassword(input.password);
      if (localUser.passwordHash !== passwordHash) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Invalid email or password",
        });
      }

      const token = generateToken(user.id);
      return { token, user: { id: user.id, email: user.email, name: user.name } };
    }),

  me: publicQuery.query(async ({ ctx }) => {
    const req = ctx.req as any;
    const token = req.headers?.get?.("x-local-auth-token");

    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token));
      if (payload.exp < Date.now()) return null;

      const db = getDb();
      const user = await db.query.users.findFirst({
        where: eq(users.id, payload.userId),
      });
      return user || null;
    } catch {
      return null;
    }
  }),
});
