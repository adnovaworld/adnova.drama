import type { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";
import type { User } from "@db/schema";
import { authenticateRequest } from "./kimi/auth";
import { getDb } from "./queries/connection";
import { users } from "@db/schema";
import { eq } from "drizzle-orm";

export type TrpcContext = {
  req: Request;
  resHeaders: Headers;
  user?: User;
};

async function authenticateLocalUser(headers: Headers): Promise<User | undefined> {
  const token = headers.get("x-local-auth-token");
  if (!token) return undefined;

  try {
    const payload = JSON.parse(atob(token));
    if (payload.exp < Date.now()) return undefined;

    const db = getDb();
    const user = await db.query.users.findFirst({
      where: eq(users.id, payload.userId),
    });
    return user || undefined;
  } catch {
    return undefined;
  }
}

export async function createContext(
  opts: FetchCreateContextFnOptions,
): Promise<TrpcContext> {
  const ctx: TrpcContext = { req: opts.req, resHeaders: opts.resHeaders };

  // Try OAuth first
  try {
    ctx.user = await authenticateRequest(opts.req.headers);
  } catch {
    // OAuth not available, try local auth
  }

  // If no OAuth user, try local auth
  if (!ctx.user) {
    try {
      ctx.user = await authenticateLocalUser(opts.req.headers);
    } catch {
      // Local auth not available
    }
  }

  return ctx;
}
