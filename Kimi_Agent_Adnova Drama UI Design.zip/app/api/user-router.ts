import { z } from "zod";
import { eq, and } from "drizzle-orm";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  userFavorites,
  userBookmarks,
  userContinue,
  users,
  notifications,
} from "@db/schema";

export const userRouter = createRouter({
  me: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const user = await db.query.users.findFirst({
      where: eq(users.id, ctx.user.id),
    });
    return user || null;
  }),

  favorites: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const favs = await db.query.userFavorites.findMany({
      where: eq(userFavorites.userId, ctx.user.id),
      with: { story: { with: { category: true } } },
    });
    return favs.map((f) => f.story);
  }),

  toggleFavorite: authedQuery
    .input(z.object({ storyId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const existing = await db.query.userFavorites.findFirst({
        where: and(
          eq(userFavorites.userId, ctx.user.id),
          eq(userFavorites.storyId, input.storyId)
        ),
      });

      if (existing) {
        await db
          .delete(userFavorites)
          .where(eq(userFavorites.id, existing.id));
        return { favorited: false };
      } else {
        await db.insert(userFavorites).values({
          userId: ctx.user.id,
          storyId: input.storyId,
        });
        return { favorited: true };
      }
    }),

  bookmarks: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db.query.userBookmarks.findMany({
      where: eq(userBookmarks.userId, ctx.user.id),
      with: {
        story: { with: { category: true } },
        episode: true,
      },
    });
  }),

  updateBookmark: authedQuery
    .input(
      z.object({
        storyId: z.number(),
        episodeId: z.number().optional(),
        progress: z.number(),
        pageNumber: z.number().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const existing = await db.query.userBookmarks.findFirst({
        where: and(
          eq(userBookmarks.userId, ctx.user.id),
          eq(userBookmarks.storyId, input.storyId)
        ),
      });

      if (existing) {
        await db
          .update(userBookmarks)
          .set({
            episodeId: input.episodeId,
            progress: input.progress,
            pageNumber: input.pageNumber,
          })
          .where(eq(userBookmarks.id, existing.id));
      } else {
        await db.insert(userBookmarks).values({
          userId: ctx.user.id,
          storyId: input.storyId,
          episodeId: input.episodeId,
          progress: input.progress,
          pageNumber: input.pageNumber,
        });
      }
      return { success: true };
    }),

  continue: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db.query.userContinue.findMany({
      where: eq(userContinue.userId, ctx.user.id),
      with: {
        story: { with: { category: true } },
        episode: true,
      },
      orderBy: (uc, { desc }) => [desc(uc.updatedAt)],
    });
  }),

  updateContinue: authedQuery
    .input(
      z.object({
        storyId: z.number(),
        episodeId: z.number().optional(),
        progress: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const existing = await db.query.userContinue.findFirst({
        where: and(
          eq(userContinue.userId, ctx.user.id),
          eq(userContinue.storyId, input.storyId)
        ),
      });

      if (existing) {
        await db
          .update(userContinue)
          .set({
            episodeId: input.episodeId,
            progress: input.progress,
          })
          .where(eq(userContinue.id, existing.id));
      } else {
        await db.insert(userContinue).values({
          userId: ctx.user.id,
          storyId: input.storyId,
          episodeId: input.episodeId,
          progress: input.progress,
        });
      }
      return { success: true };
    }),

  notifications: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db.query.notifications.findMany({
      where: eq(notifications.userId, ctx.user.id),
      orderBy: (n, { desc }) => [desc(n.createdAt)],
      limit: 20,
    });
  }),

  markNotificationRead: authedQuery
    .input(z.object({ notificationId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(notifications)
        .set({ isRead: true })
        .where(eq(notifications.id, input.notificationId));
      return { success: true };
    }),

  updateProfile: authedQuery
    .input(
      z.object({
        name: z.string().optional(),
        avatar: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db
        .update(users)
        .set(input)
        .where(eq(users.id, ctx.user.id));
      return { success: true };
    }),
});
