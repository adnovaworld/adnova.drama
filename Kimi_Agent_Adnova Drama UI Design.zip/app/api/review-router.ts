import { z } from "zod";
import { eq, and, desc, sql } from "drizzle-orm";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { reviews } from "@db/schema";

export const reviewRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        storyId: z.number(),
        page: z.number().default(1),
        limit: z.number().default(10),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const items = await db.query.reviews.findMany({
        where: eq(reviews.storyId, input.storyId),
        with: { user: true },
        orderBy: [desc(reviews.createdAt)],
        limit: input.limit,
        offset: (input.page - 1) * input.limit,
      });

      const avgResult = await db
        .select({ avg: sql<string>`avg(${reviews.rating})` })
        .from(reviews)
        .where(eq(reviews.storyId, input.storyId));

      const totalResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(reviews)
        .where(eq(reviews.storyId, input.storyId));

      return {
        reviews: items,
        averageRating: parseFloat(avgResult[0]?.avg || "0"),
        total: Number(totalResult[0]?.count || 0),
      };
    }),

  create: authedQuery
    .input(
      z.object({
        storyId: z.number(),
        rating: z.number().min(1).max(5),
        comment: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const existing = await db.query.reviews.findFirst({
        where: and(
          eq(reviews.userId, ctx.user.id),
          eq(reviews.storyId, input.storyId)
        ),
      });

      if (existing) {
        await db
          .update(reviews)
          .set({
            rating: input.rating,
            comment: input.comment || existing.comment,
          })
          .where(eq(reviews.id, existing.id));
        return { updated: true };
      }

      await db.insert(reviews).values({
        userId: ctx.user.id,
        storyId: input.storyId,
        rating: input.rating,
        comment: input.comment,
      });
      return { created: true };
    }),
});
